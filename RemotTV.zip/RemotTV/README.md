# Remot TV

Aplikasi Android yang menjadikan HP sebagai remot untuk Android TV / Google TV
(dibuat untuk Toshiba 43V35). Terhubung lewat WiFi memakai protokol remote resmi
Android TV, jadi tidak perlu mengaktifkan mode developer di TV.

Fitur: tombol arah dan OK (bisa ditahan), Kembali, Beranda, Menu, area geser untuk
scroll, Page Up/Down, volume (tombol volume HP juga bisa), putar/jeda, daya, input,
cari, pengaturan, dan mengetik langsung ke kolom teks di TV.

## Membuat APK dengan GitHub Actions

1. Buat repository baru di GitHub, lalu unggah semua isi folder ini
   (termasuk folder `.github`).
2. Workflow **Build APK** berjalan otomatis setiap ada push ke `main`.
   Bisa juga dijalankan manual dari tab **Actions → Build APK → Run workflow**.
3. Setelah selesai (sekitar 3–5 menit), unduh `RemotTV.apk` dari halaman
   **Releases** repository, atau dari bagian **Artifacts** di hasil workflow.

## Cara pakai

1. Pasang APK di HP (izinkan "pasang dari sumber tidak dikenal").
2. Pastikan HP dan TV tersambung ke WiFi yang sama, lalu buka aplikasi.
3. Ketuk **Pilih TV**. TV akan muncul otomatis; kalau tidak, ketik IP TV
   (lihat di TV: Pengaturan → Jaringan & Internet → nama WiFi).
4. TV menampilkan kode 6 karakter. Ketik kode itu di HP lalu ketuk **Pasangkan**.
   Pairing hanya perlu sekali.

Untuk mengetik: pilih dulu kolom teks di TV (misalnya pencarian YouTube), lalu ketik
di kolom **Ketik ke TV**. Teks langsung muncul di TV. Tombol Enter mengirim pencarian.
