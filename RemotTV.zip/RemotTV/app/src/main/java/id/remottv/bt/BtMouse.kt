package id.remottv.bt

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.annotation.TargetApi
import java.util.concurrent.Executors

/**
 * Menjadikan HP sebagai mouse Bluetooth. Android TV menampilkan kursor saat mouse
 * Bluetooth tersambung, jadi tidak perlu aplikasi apa pun di TV.
 *
 * Butuh Android 9 ke atas dan HP yang mendukung profil "HID Device".
 */
@SuppressLint("MissingPermission") // izin diminta oleh MainActivity sebelum kelas ini dipakai
@TargetApi(Build.VERSION_CODES.P)
class BtMouse(private val ctx: Context, private val listener: Listener) {

    interface Listener {
        /** Status siap dipasangkan (aplikasi mouse terdaftar di Bluetooth HP). */
        fun onRegistered(registered: Boolean)
        fun onConnected(device: BluetoothDevice?)
        fun onUnsupported(reason: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private val sender = Executors.newSingleThreadExecutor()
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private var hid: BluetoothHidDevice? = null
    @Volatile var device: BluetoothDevice? = null
        private set
    var registered = false
        private set
    private var wantConnectTo: String? = null
    private var buttons = 0

    val isBluetoothOn get() = adapter?.isEnabled == true
    val isConnected get() = device != null

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, reg: Boolean) {
            registered = reg
            main.post { listener.onRegistered(reg) }
            if (reg) {
                val target = pluggedDevice ?: wantConnectTo?.let { addr ->
                    adapter?.bondedDevices?.firstOrNull { it.address == addr }
                }
                target?.let { hid?.connect(it) }
            }
        }

        override fun onConnectionStateChanged(d: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    device = d
                    main.post { listener.onConnected(d) }
                }
                BluetoothProfile.STATE_DISCONNECTED -> if (device == null || device?.address == d.address) {
                    device = null
                    main.post { listener.onConnected(null) }
                }
            }
        }
    }

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            val h = proxy as BluetoothHidDevice
            hid = h
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "Remot TV Mouse", "Mouse dari HP", "RemotTV",
                BluetoothHidDevice.SUBCLASS1_MOUSE, DESCRIPTOR,
            )
            val ok = h.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), callback)
            if (!ok) main.post { listener.onUnsupported("HP ini menolak menjadi mouse Bluetooth.") }
        }

        override fun onServiceDisconnected(profile: Int) {
            hid = null; registered = false; device = null
            main.post { listener.onRegistered(false); listener.onConnected(null) }
        }
    }

    /** Mulai: daftarkan HP sebagai mouse; kalau [lastAddress] diisi, langsung sambungkan. */
    fun start(lastAddress: String?) {
        wantConnectTo = lastAddress
        val a = adapter
        if (a == null) { listener.onUnsupported("HP ini tidak punya Bluetooth."); return }
        if (!a.isEnabled) return
        if (hid != null) {
            if (registered && device == null) lastAddress?.let { connectTo(it) }
            return
        }
        val ok = a.getProfileProxy(ctx, profileListener, BluetoothProfile.HID_DEVICE)
        if (!ok) listener.onUnsupported("HP ini tidak mendukung mode mouse Bluetooth.")
    }

    fun connectTo(address: String) {
        wantConnectTo = address
        val d = adapter?.bondedDevices?.firstOrNull { it.address == address } ?: return
        hid?.connect(d)
    }

    fun bondedDevices(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()

    fun stop() {
        val h = hid ?: return
        try {
            device?.let { h.disconnect(it) }
            h.unregisterApp()
        } catch (_: Exception) {}
        try { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, h) } catch (_: Exception) {}
        hid = null; registered = false; device = null
    }

    /* --------------------------- laporan mouse --------------------------- */

    fun move(dx: Int, dy: Int) = report(buttons, dx, dy, 0)

    fun wheel(steps: Int) = report(buttons, 0, 0, steps)

    fun click() {
        report(1, 0, 0, 0)
        report(0, 0, 0, 0)
    }

    fun press(down: Boolean) {
        buttons = if (down) 1 else 0
        report(buttons, 0, 0, 0)
    }

    private fun report(btn: Int, dx: Int, dy: Int, wh: Int) {
        val h = hid ?: return
        val d = device ?: return
        // gerakan besar dipecah jadi beberapa laporan (batas -127..127 per laporan)
        var rx = dx; var ry = dy; var rw = wh
        sender.execute {
            do {
                val x = rx.coerceIn(-127, 127); val y = ry.coerceIn(-127, 127); val w = rw.coerceIn(-127, 127)
                rx -= x; ry -= y; rw -= w
                try {
                    h.sendReport(d, REPORT_ID, byteArrayOf(btn.toByte(), x.toByte(), y.toByte(), w.toByte()))
                } catch (_: Exception) { return@execute }
            } while (rx != 0 || ry != 0 || rw != 0)
        }
    }

    companion object {
        private const val REPORT_ID = 1

        // Mouse standar: 3 tombol, gerak X/Y relatif, roda scroll
        private val DESCRIPTOR = byteArrayOf(
            0x05, 0x01,             // Usage Page (Generic Desktop)
            0x09, 0x02,             // Usage (Mouse)
            0xA1.toByte(), 0x01,    // Collection (Application)
            0x85.toByte(), 0x01,    //   Report ID (1)
            0x09, 0x01,             //   Usage (Pointer)
            0xA1.toByte(), 0x00,    //   Collection (Physical)
            0x05, 0x09,             //     Usage Page (Buttons)
            0x19, 0x01,             //     Usage Minimum (1)
            0x29, 0x03,             //     Usage Maximum (3)
            0x15, 0x00,             //     Logical Minimum (0)
            0x25, 0x01,             //     Logical Maximum (1)
            0x95.toByte(), 0x03,    //     Report Count (3)
            0x75, 0x01,             //     Report Size (1)
            0x81.toByte(), 0x02,    //     Input (Data, Var, Abs)
            0x95.toByte(), 0x01,    //     Report Count (1)
            0x75, 0x05,             //     Report Size (5)
            0x81.toByte(), 0x03,    //     Input (Const) — padding
            0x05, 0x01,             //     Usage Page (Generic Desktop)
            0x09, 0x30,             //     Usage (X)
            0x09, 0x31,             //     Usage (Y)
            0x09, 0x38,             //     Usage (Wheel)
            0x15, 0x81.toByte(),    //     Logical Minimum (-127)
            0x25, 0x7F,             //     Logical Maximum (127)
            0x75, 0x08,             //     Report Size (8)
            0x95.toByte(), 0x03,    //     Report Count (3)
            0x81.toByte(), 0x06,    //     Input (Data, Var, Rel)
            0xC0.toByte(),          //   End Collection
            0xC0.toByte(),          // End Collection
        )
    }
}
