package id.remottv.atv

import org.bouncycastle.asn1.ASN1EncodableVector
import org.bouncycastle.asn1.ASN1Encoding
import org.bouncycastle.asn1.ASN1Integer
import org.bouncycastle.asn1.DERBitString
import org.bouncycastle.asn1.DERNull
import org.bouncycastle.asn1.DERSequence
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.AlgorithmIdentifier
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.Extensions
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo
import org.bouncycastle.asn1.x509.Time
import org.bouncycastle.asn1.x509.V3TBSCertificateGenerator
import java.io.ByteArrayInputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Menyimpan sertifikat klien milik aplikasi. TV mengingat sertifikat ini setelah pairing,
 * jadi pairing cukup sekali.
 */
class CertStore(private val dir: File) {
    private val file = File(dir, "client.p12")
    private val password = "remottv".toCharArray()
    private val alias = "client"

    @Volatile private var keyStore: KeyStore? = null

    @Synchronized
    fun keyStore(): KeyStore {
        keyStore?.let { return it }
        val ks = KeyStore.getInstance("PKCS12")
        if (file.exists()) {
            try {
                file.inputStream().use { ks.load(it, password) }
                if (ks.containsAlias(alias)) { keyStore = ks; return ks }
            } catch (_: Exception) { /* buat ulang */ }
        }
        val fresh = generate()
        dir.mkdirs()
        file.outputStream().use { fresh.store(it, password) }
        keyStore = fresh
        return fresh
    }

    fun certificate(): X509Certificate = keyStore().getCertificate(alias) as X509Certificate

    /** Hapus sertifikat supaya pairing dimulai dari awal. */
    @Synchronized
    fun reset() {
        file.delete(); keyStore = null
    }

    fun sslContext(): SSLContext {
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore(), password)
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        return SSLContext.getInstance("TLS").apply {
            init(kmf.keyManagers, arrayOf<TrustManager>(trustAll), SecureRandom())
        }
    }

    private fun generate(): KeyStore {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()

        val name = X500Name("CN=atvremote")
        val sigAlg = AlgorithmIdentifier(PKCSObjectIdentifiers.sha256WithRSAEncryption, DERNull.INSTANCE)
        val now = System.currentTimeMillis()
        val gen = V3TBSCertificateGenerator().apply {
            setSerialNumber(ASN1Integer(BigInteger(63, SecureRandom()).add(BigInteger.ONE)))
            setIssuer(name)
            setSubject(name)
            setStartDate(Time(Date(now - 24L * 3600 * 1000)))
            setEndDate(Time(Date(now + 10L * 365 * 24 * 3600 * 1000)))
            setSignature(sigAlg)
            setSubjectPublicKeyInfo(SubjectPublicKeyInfo.getInstance(kp.public.encoded))
            setExtensions(
                Extensions(
                    arrayOf(
                        Extension(Extension.basicConstraints, true, BasicConstraints(0).getEncoded(ASN1Encoding.DER)),
                        Extension(
                            Extension.subjectAlternativeName, false,
                            GeneralNames(GeneralName(GeneralName.dNSName, "atvremote")).getEncoded(ASN1Encoding.DER),
                        ),
                    )
                )
            )
        }
        val tbs = gen.generateTBSCertificate()
        val signature = Signature.getInstance("SHA256withRSA").run {
            initSign(kp.private)
            update(tbs.getEncoded(ASN1Encoding.DER))
            sign()
        }
        val v = ASN1EncodableVector().apply {
            add(tbs); add(sigAlg); add(DERBitString(signature))
        }
        val der = DERSequence(v).getEncoded(ASN1Encoding.DER)
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(der)) as X509Certificate

        return KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry(alias, kp.private, password, arrayOf(cert))
        }
    }
}
