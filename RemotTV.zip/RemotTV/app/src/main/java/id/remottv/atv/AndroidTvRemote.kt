package id.remottv.atv

import java.io.Closeable
import java.io.IOException
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.interfaces.RSAPublicKey
import java.security.cert.X509Certificate
import java.util.concurrent.Executors
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket

/**
 * Protokol "Android TV Remote v2" (dipakai aplikasi Google TV resmi).
 * Port 6467 untuk pairing, port 6466 untuk perintah.
 */
const val PAIRING_PORT = 6467
const val REMOTE_PORT = 6466

class PairingException(msg: String) : Exception(msg)
class NotPairedException : Exception("HP belum dipasangkan (pairing) dengan TV ini")

object Keys {
    const val HOME = 3
    const val BACK = 4
    const val UP = 19
    const val DOWN = 20
    const val LEFT = 21
    const val RIGHT = 22
    const val OK = 23
    const val VOL_UP = 24
    const val VOL_DOWN = 25
    const val POWER = 26
    const val ENTER = 66
    const val SHIFT = 59
    const val DEL = 67
    const val MENU = 82
    const val SEARCH = 84
    const val PLAY_PAUSE = 85
    const val REWIND = 89
    const val FAST_FORWARD = 90
    const val PAGE_UP = 92
    const val PAGE_DOWN = 93
    const val MUTE = 164
    const val SETTINGS = 176
    const val INPUT = 178
}

private fun openSocket(certs: CertStore, host: String, port: Int): SSLSocket {
    val factory = certs.sslContext().socketFactory
    val raw = java.net.Socket()
    raw.connect(InetSocketAddress(host, port), 5000)
    val s = factory.createSocket(raw, host, port, true) as SSLSocket
    s.soTimeout = 15000
    s.startHandshake()
    return s
}

/* ============================== PAIRING ============================== */

class Pairing(
    private val certs: CertStore,
    private val host: String,
    private val clientName: String,
    private val port: Int = PAIRING_PORT,
) : Closeable {
    private var socket: SSLSocket? = null

    private fun outer(build: ProtoWriter.() -> Unit): ByteArray =
        ProtoWriter().int(1, 2).int(2, 200).apply(build).toByteArray()

    private fun send(bytes: ByteArray) = Framing.write(socket!!.outputStream, bytes)

    private fun receive(): ProtoMsg {
        val m = ProtoMsg(Framing.read(socket!!.inputStream))
        val status = m.int(2, 200)
        if (status != 200) {
            throw PairingException(
                when (status) {
                    402 -> "Kode salah. Coba lagi."
                    401 -> "Konfigurasi pairing ditolak TV"
                    else -> "TV menolak pairing (status $status)"
                }
            )
        }
        return m
    }

    /** Langkah 1: minta TV menampilkan kode 6 karakter di layar. */
    fun start() {
        socket = openSocket(certs, host, port)
        send(outer { msg(10) { string(1, "atvremote"); string(2, clientName) } })
        while (true) {
            val m = receive()
            when {
                m.has(11) -> send(outer {   // pairing_request_ack -> options
                    msg(20) {
                        msg(1) { int(1, 3); int(2, 6) } // input encoding: HEX, 6 karakter
                        int(3, 1)                       // role: INPUT
                    }
                })
                m.has(20) -> send(outer {   // options -> configuration
                    msg(30) {
                        msg(1) { int(1, 3); int(2, 6) }
                        int(2, 1)
                    }
                })
                m.has(31) -> return         // configuration_ack: kode tampil di TV
                else -> throw PairingException("Balasan TV tidak dikenal: ${m.fieldNumbers()}")
            }
        }
    }

    /** Langkah 2: kirim kode yang tampil di TV. */
    fun finish(rawCode: String) {
        val code = rawCode.trim().uppercase()
        if (code.length != 6 || !code.all { it in "0123456789ABCDEF" })
            throw PairingException("Kode harus 6 karakter (0-9 dan A-F)")
        val s = socket ?: throw PairingException("Pairing belum dimulai")

        val client = certs.certificate().publicKey as RSAPublicKey
        val server = (s.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey
        val secret = computeSecret(client, server, code)
        if ((secret[0].toInt() and 0xFF) != code.substring(0, 2).toInt(16))
            throw PairingException("Kode salah. Periksa lagi kode di layar TV.")

        send(outer { msg(40) { bytes(1, secret) } })
        val m = receive()
        if (!m.has(41)) throw PairingException("TV tidak mengonfirmasi pairing")
        close()
    }

    override fun close() {
        try { socket?.close() } catch (_: IOException) {}
        socket = null
    }

    companion object {
        private fun hexBytes(hex: String): ByteArray {
            val h = if (hex.length % 2 == 1) "0$hex" else hex
            return ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        }

        private fun hex(n: BigInteger) = n.toString(16).uppercase()

        fun computeSecret(client: RSAPublicKey, server: RSAPublicKey, code: String): ByteArray {
            val md = MessageDigest.getInstance("SHA-256")
            md.update(hexBytes(hex(client.modulus)))
            md.update(hexBytes("0" + hex(client.publicExponent)))
            md.update(hexBytes(hex(server.modulus)))
            md.update(hexBytes("0" + hex(server.publicExponent)))
            md.update(hexBytes(code.substring(2)))
            return md.digest()
        }
    }
}

/* ============================== REMOTE ============================== */

class RemoteClient(
    private val certs: CertStore,
    private val host: String,
    private val listener: Listener,
    private val port: Int = REMOTE_PORT,
) {
    interface Listener {
        fun onReady()
        fun onDisconnected(error: Exception?)
        fun onVolume(level: Int, max: Int, muted: Boolean) {}
        fun onTvKeyboard(active: Boolean) {}
    }

    // PING | KEY | IME | POWER | VOLUME | APP_LINK
    private val features = 1 or 2 or 4 or 32 or 64 or 512

    private var socket: SSLSocket? = null
    private val writer = Executors.newSingleThreadExecutor()
    @Volatile private var closed = false
    @Volatile private var imeCounter = 0
    @Volatile private var fieldCounter = 0
    @Volatile var ready = false
        private set

    /** Blocking. Melempar NotPairedException jika TV belum mengenal HP ini. */
    fun connect() {
        val s = try {
            openSocket(certs, host, port)
        } catch (e: SSLException) {
            throw NotPairedException()
        } catch (e: IOException) {
            // TV menutup koneksi saat handshake = sertifikat belum dikenal
            if (e.message?.contains("reset", true) == true ||
                e.message?.contains("closed", true) == true) throw NotPairedException()
            throw e
        }
        s.soTimeout = 0
        socket = s
        Thread({ readLoop(s) }, "atv-reader").apply { isDaemon = true }.start()
    }

    private fun readLoop(s: SSLSocket) {
        var error: Exception? = null
        try {
            // TV mengirim ping tiap ~5 detik; kalau 20 detik sepi, anggap putus
            s.soTimeout = 20000
            while (!closed) handle(ProtoMsg(Framing.read(s.inputStream)))
        } catch (e: Exception) {
            error = e
        }
        val wasReady = ready
        ready = false
        if (!closed) {
            close()
            // TV menolak sertifikat yang belum dipasangkan dengan menutup koneksi sebelum siap
            val notPaired = !wasReady && (error is SSLException || error is java.io.EOFException)
            listener.onDisconnected(if (notPaired) NotPairedException() else error)
        }
    }

    private fun handle(m: ProtoMsg) {
        when {
            m.has(1) -> send {   // remote_configure
                msg(1) {
                    int(1, features)
                    msg(2) {
                        string(1, "Remot TV")
                        string(2, "RemotTV")
                        int(3, 1)
                        string(4, "1")
                        string(5, "id.remottv")
                        string(6, "1.0.0")
                    }
                }
            }
            m.has(2) -> send { msg(2) { int(1, features) } }               // set_active
            m.has(8) -> send { msg(9) { int(1, m.msg(8).int(1)) } }        // ping -> pong
            m.has(21) -> {                                                 // keyboard TV aktif
                val b = m.msg(21)
                imeCounter = b.int(1); fieldCounter = b.int(2)
                listener.onTvKeyboard(true)
            }
            m.has(22) -> listener.onTvKeyboard(true)                       // ime_show_request
            m.has(40) -> {                                                 // remote_start
                if (!ready) { ready = true; listener.onReady() }
            }
            m.has(50) -> {
                val v = m.msg(50)
                listener.onVolume(v.int(7), v.int(6), v.long(8) != 0L)
            }
        }
    }

    private fun send(build: ProtoWriter.() -> Unit) {
        val bytes = ProtoWriter().apply(build).toByteArray()
        val s = socket ?: return
        if (writer.isShutdown) return
        writer.execute {
            try { Framing.write(s.outputStream, bytes) } catch (_: IOException) { }
        }
    }

    /** direction: 3 = tekan singkat, 1 = mulai tahan, 2 = lepas. */
    fun key(code: Int, direction: Int = 3) = send {
        msg(10) { int(1, code); int(2, direction) }
    }

    /** Mengisi kolom teks yang sedang aktif di TV dengan [text]. */
    fun text(text: String) {
        if (text.isEmpty()) return
        val pos = text.length - 1
        send {
            msg(21) {
                int(1, imeCounter)
                int(2, fieldCounter)
                msg(3) {
                    int(1, 1)
                    msg(2) { int(1, pos); int(2, pos); string(3, text) }
                }
            }
        }
    }

    /**
     * Mengetik huruf demi huruf sebagai tombol keyboard. Cara ini bekerja di semua kolom teks
     * dan tidak bergantung pada cara keyboard TV memproses teks kiriman.
     */
    fun type(s: String) {
        for (ch in s) {
            val plain = plainKey(ch)
            if (plain != null) { key(plain); continue }
            val shifted = shiftedKey(ch)
            if (shifted != null) {
                key(Keys.SHIFT, 1); key(shifted); key(Keys.SHIFT, 2)
                continue
            }
            text(ch.toString()) // huruf khusus (misalnya é, emoji)
        }
    }

    private fun plainKey(ch: Char): Int? = when (ch) {
        in 'a'..'z' -> 29 + (ch - 'a')
        in '0'..'9' -> 7 + (ch - '0')
        ' ' -> 62
        '.' -> 56
        ',' -> 55
        '-' -> 69
        '=' -> 70
        '[' -> 71
        ']' -> 72
        '\\' -> 73
        ';' -> 74
        '\'' -> 75
        '/' -> 76
        '@' -> 77
        '+' -> 81
        '*' -> 17
        '#' -> 18
        '`' -> 68
        '\n' -> Keys.ENTER
        else -> null
    }

    private fun shiftedKey(ch: Char): Int? = when (ch) {
        in 'A'..'Z' -> 29 + (ch - 'A')
        '!' -> 8
        '$' -> 11
        '%' -> 12
        '^' -> 13
        '&' -> 14
        '(' -> 16
        ')' -> 7
        '_' -> 69
        ':' -> 74
        '"' -> 75
        '?' -> 76
        '<' -> 55
        '>' -> 56
        '{' -> 71
        '}' -> 72
        '|' -> 73
        '~' -> 68
        else -> null
    }

    fun openApp(link: String) = send { msg(90) { string(1, link) } }

    fun close() {
        closed = true
        ready = false
        writer.shutdown()
        try { socket?.close() } catch (_: IOException) {}
        socket = null
    }
}
