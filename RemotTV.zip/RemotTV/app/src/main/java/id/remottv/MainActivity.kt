package id.remottv

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import id.remottv.atv.CertStore
import id.remottv.atv.Keys
import id.remottv.atv.NotPairedException
import id.remottv.atv.Pairing
import id.remottv.atv.PairingException
import id.remottv.atv.RemoteClient
import id.remottv.ui.DpadView
import id.remottv.ui.TouchpadView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var certs: CertStore
    private val prefs by lazy { getSharedPreferences("tv", Context.MODE_PRIVATE) }

    private var client: RemoteClient? = null
    private var started = false
    private var pairingDialog: AlertDialog? = null

    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var typeField: EditText

    private val tvHost get() = prefs.getString("host", null)
    private val tvName get() = prefs.getString("name", null) ?: tvHost ?: "TV"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        applyInsets(findViewById(R.id.scroll))
        certs = CertStore(filesDir)

        statusText = findViewById(R.id.statusText)
        statusDot = findViewById(R.id.statusDot)
        typeField = findViewById(R.id.typeField)

        findViewById<View>(R.id.btnChooseTv).setOnClickListener { showTvPicker() }
        findViewById<View>(R.id.statusBar).setOnClickListener {
            if (client?.ready != true) tvHost?.let { connect() } ?: showTvPicker()
        }

        findViewById<DpadView>(R.id.dpad).onPress = { part ->
            key(
                when (part) {
                    DpadView.Part.UP -> Keys.UP
                    DpadView.Part.DOWN -> Keys.DOWN
                    DpadView.Part.LEFT -> Keys.LEFT
                    DpadView.Part.RIGHT -> Keys.RIGHT
                    DpadView.Part.OK -> Keys.OK
                }
            )
        }
        findViewById<TouchpadView>(R.id.touchpad).apply {
            onStep = { d ->
                key(
                    when (d) {
                        TouchpadView.Dir.UP -> Keys.UP
                        TouchpadView.Dir.DOWN -> Keys.DOWN
                        TouchpadView.Dir.LEFT -> Keys.LEFT
                        TouchpadView.Dir.RIGHT -> Keys.RIGHT
                    }
                )
            }
            onTap = { key(Keys.OK) }
        }

        bindKey(R.id.btnPower, Keys.POWER)
        bindKey(R.id.btnInput, Keys.INPUT)
        bindKey(R.id.btnSearch, Keys.SEARCH)
        bindKey(R.id.btnSettings, Keys.SETTINGS)
        bindKey(R.id.btnBack, Keys.BACK)
        bindKey(R.id.btnHome, Keys.HOME)
        bindKey(R.id.btnMenu, Keys.MENU)
        bindKey(R.id.btnPageUp, Keys.PAGE_UP)
        bindKey(R.id.btnPageDown, Keys.PAGE_DOWN)
        bindKey(R.id.btnVolDown, Keys.VOL_DOWN)
        bindKey(R.id.btnVolUp, Keys.VOL_UP)
        bindKey(R.id.btnMute, Keys.MUTE)
        bindKey(R.id.btnRew, Keys.REWIND)
        bindKey(R.id.btnPlay, Keys.PLAY_PAUSE)
        bindKey(R.id.btnFf, Keys.FAST_FORWARD)

        setupTyping()
        setStatus("Belum terhubung", Status.IDLE)
    }

    override fun onStart() {
        super.onStart()
        started = true
        if (tvHost != null) connect() else ui.postDelayed({ if (tvHost == null) showTvPicker() }, 400)
    }

    override fun onStop() {
        started = false
        ui.removeCallbacksAndMessages(null)
        client?.close(); client = null
        super.onStop()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    // Android 15 menggambar aplikasi sampai ke tepi layar: beri jarak untuk status bar & keyboard
    private fun applyInsets(root: View) {
        if (Build.VERSION.SDK_INT < 35) return
        root.setOnApplyWindowInsetsListener { v, insets ->
            val i = insets.getInsets(
                WindowInsets.Type.systemBars() or WindowInsets.Type.ime() or WindowInsets.Type.displayCutout()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsets.CONSUMED
        }
    }

    /* ------------------------- tombol ------------------------- */

    private fun bindKey(id: Int, code: Int) {
        findViewById<ImageButton>(id).setOnClickListener { key(code) }
    }

    private fun key(code: Int) {
        val c = client
        if (c == null || !c.ready) {
            if (tvHost == null) toast("Pilih TV dulu") else toast("Belum terhubung ke TV")
            return
        }
        c.key(code)
    }

    // Tombol volume HP ikut mengatur volume TV
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val c = client
        if (c != null && c.ready) {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> { c.key(Keys.VOL_UP); return true }
                KeyEvent.KEYCODE_VOLUME_DOWN -> { c.key(Keys.VOL_DOWN); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    /* ------------------------- mengetik ------------------------- */

    private var lastSent = ""
    private var suppressSync = false
    private val syncRunnable = Runnable { syncText() }

    private fun setupTyping() {
        typeField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressSync) return
                ui.removeCallbacks(syncRunnable)
                ui.postDelayed(syncRunnable, 120)
            }
        })
        typeField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                pressEnter(); true
            } else false
        }
        findViewById<View>(R.id.btnEnter).setOnClickListener { pressEnter() }
        findViewById<View>(R.id.btnBackspace).setOnClickListener {
            val t = typeField.text
            if (t.isNotEmpty()) t.delete(t.length - 1, t.length) else key(Keys.DEL)
        }
    }

    private fun syncText() {
        val c = client ?: return
        if (!c.ready) return
        val t = typeField.text.toString()
        if (t == lastSent) return
        if (t.isEmpty()) {
            repeat(lastSent.length.coerceAtMost(60)) { c.key(Keys.DEL) }
        } else {
            c.text(t)
        }
        lastSent = t
    }

    private fun pressEnter() {
        ui.removeCallbacks(syncRunnable)
        syncText()
        key(Keys.ENTER)
        // kosongkan kolom di HP tanpa menghapus teks di TV
        suppressSync = true
        typeField.setText("")
        suppressSync = false
        lastSent = ""
    }

    /* ------------------------- koneksi ------------------------- */

    private enum class Status { IDLE, BUSY, OK, ERROR }

    private fun setStatus(text: String, s: Status) {
        statusText.text = text
        val color = when (s) {
            Status.OK -> getColor(R.color.live)
            Status.BUSY -> getColor(R.color.ok)
            Status.ERROR -> getColor(R.color.power)
            Status.IDLE -> getColor(R.color.muted)
        }
        (statusDot.background.mutate() as? GradientDrawable)?.setColor(color)
    }

    private fun connect() {
        val host = tvHost ?: return
        client?.close(); client = null
        setStatus("Menghubungkan ke $tvName…", Status.BUSY)
        val c = RemoteClient(certs, host, object : RemoteClient.Listener {
            override fun onReady() {
                ui.post {
                    setStatus("Terhubung ke $tvName", Status.OK)
                    lastSent = ""
                }
            }

            override fun onDisconnected(error: Exception?) {
                ui.post { handleDisconnect(error) }
            }
        })
        client = c
        io.execute {
            try {
                c.connect()
            } catch (e: NotPairedException) {
                ui.post { if (client === c) { client = null; startPairing() } }
            } catch (e: Exception) {
                ui.post {
                    if (client === c) {
                        client = null
                        setStatus("TV tidak terjangkau. Pastikan TV menyala dan satu WiFi dengan HP.", Status.ERROR)
                    }
                }
            }
        }
    }

    private fun handleDisconnect(error: Exception?) {
        if (!started) return
        client = null
        if (error is NotPairedException) {
            startPairing()
        } else {
            setStatus("Koneksi terputus. Ketuk untuk sambung lagi.", Status.ERROR)
            ui.postDelayed({ if (started && client == null) connect() }, 2500)
        }
    }

    /* ------------------------- pairing ------------------------- */

    private var pairing: Pairing? = null

    private fun startPairing() {
        val host = tvHost ?: return
        if (!started) return
        setStatus("Menunggu kode dari TV…", Status.BUSY)
        pairing?.close()
        val p = Pairing(certs, host, Build.MODEL ?: "HP Android")
        pairing = p
        io.execute {
            try {
                p.start()
                ui.post { showCodeDialog(p) }
            } catch (e: Exception) {
                ui.post {
                    setStatus("Pairing gagal dimulai. Ketuk untuk coba lagi.", Status.ERROR)
                    toast(e.message ?: "Pairing gagal")
                }
            }
        }
    }

    private fun showCodeDialog(p: Pairing) {
        pairingDialog?.dismiss()
        val input = EditText(this).apply {
            hint = "Contoh: 4F2A9C"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.LengthFilter(6), InputFilter.AllCaps())
            textSize = 24f
            gravity = Gravity.CENTER
            letterSpacing = 0.2f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
            addView(TextView(context).apply {
                text = "Masukkan 6 karakter yang muncul di layar TV."
                textSize = 15f
            })
            addView(input)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Pasangkan dengan $tvName")
            .setView(box)
            .setPositiveButton("Pasangkan", null)
            .setNegativeButton("Batal") { _, _ ->
                p.close(); pairing = null
                setStatus("Pairing dibatalkan. Ketuk untuk coba lagi.", Status.IDLE)
            }
            .setCancelable(false)
            .create()
        dlg.setOnShowListener {
            val btn = dlg.getButton(AlertDialog.BUTTON_POSITIVE)
            btn.setOnClickListener {
                val code = input.text.toString()
                btn.isEnabled = false
                io.execute {
                    try {
                        p.finish(code)
                        ui.post {
                            dlg.dismiss(); pairing = null
                            toast("Berhasil dipasangkan")
                            connect()
                        }
                    } catch (e: PairingException) {
                        ui.post {
                            btn.isEnabled = true
                            input.error = e.message
                            if (e.message?.startsWith("Kode") != true) { dlg.dismiss(); startPairing() }
                        }
                    } catch (e: Exception) {
                        // TV menutup sesi (misalnya kode kedaluwarsa): mulai lagi dengan kode baru
                        ui.post { dlg.dismiss(); toast("Kode kedaluwarsa, TV menampilkan kode baru"); startPairing() }
                    }
                }
            }
        }
        pairingDialog = dlg
        dlg.show()
        input.requestFocus()
    }

    /* ------------------------- cari TV ------------------------- */

    private data class FoundTv(val name: String, val host: String) {
        override fun toString() = "$name\n$host"
    }

    private fun showTvPicker() {
        val nsd = getSystemService(Context.NSD_SERVICE) as NsdManager
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("remottv").apply { setReferenceCounted(false); acquire() }

        val found = mutableListOf<FoundTv>()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, found)
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()

        val searching = TextView(this).apply {
            text = "Mencari TV di WiFi ini…"
            setPadding(pad, pad / 2, pad, pad / 2)
        }
        val list = ListView(this).apply {
            this.adapter = adapter
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (200 * density).toInt())
        }
        val ipField = EditText(this).apply {
            hint = "Atau ketik IP TV, misalnya 192.168.1.20"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(tvHost ?: "")
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(searching); addView(list)
            addView(LinearLayout(context).apply {
                setPadding(pad, 0, pad, 0); addView(ipField, LinearLayout.LayoutParams(-1, -2))
            })
        }

        // mDNS: TV Android/Google TV mengiklankan layanan _androidtvremote2._tcp
        val resolveQueue = ArrayDeque<NsdServiceInfo>()
        var resolving = false
        fun resolveNext() {
            if (resolving) return
            val info = resolveQueue.removeFirstOrNull() ?: return
            resolving = true
            @Suppress("DEPRECATION")
            nsd.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(s: NsdServiceInfo, err: Int) {
                    ui.post { resolving = false; resolveNext() }
                }

                override fun onServiceResolved(s: NsdServiceInfo) {
                    @Suppress("DEPRECATION")
                    val ip = s.host?.hostAddress
                    ui.post {
                        resolving = false
                        if (ip != null && found.none { it.host == ip }) {
                            found.add(FoundTv(s.serviceName, ip))
                            adapter.notifyDataSetChanged()
                            searching.text = "Ketuk TV Anda:"
                        }
                        resolveNext()
                    }
                }
            })
        }
        val discovery = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {
                ui.post { searching.text = "Pencarian otomatis gagal. Ketik IP TV di bawah." }
            }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                ui.post { resolveQueue.addLast(s); resolveNext() }
            }
        }
        nsd.discoverServices("_androidtvremote2._tcp", NsdManager.PROTOCOL_DNS_SD, discovery)
        ui.postDelayed({
            if (found.isEmpty()) searching.text =
                "Belum ada TV yang terlihat. Pastikan TV menyala dan satu WiFi dengan HP, atau ketik IP TV."
        }, 6000)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Pilih TV")
            .setView(box)
            .setPositiveButton("Hubungkan ke IP", null)
            .setNegativeButton("Tutup", null)
            .create()

        fun choose(name: String, host: String) {
            prefs.edit().putString("host", host).putString("name", name).apply()
            dlg.dismiss()
            connect()
        }
        list.setOnItemClickListener { _, _, pos, _ -> found[pos].let { choose(it.name, it.host) } }
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val ip = ipField.text.toString().trim()
                if (!Regex("""^[\w.\-]+$""").matches(ip)) ipField.error = "Isi IP TV dulu"
                else choose(if (ip == tvHost) tvName else ip, ip)
            }
        }
        dlg.setOnDismissListener {
            try { nsd.stopServiceDiscovery(discovery) } catch (_: Exception) {}
            lock.release()
        }
        dlg.show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
