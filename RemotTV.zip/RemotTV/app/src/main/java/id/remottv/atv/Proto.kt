package id.remottv.atv

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream

/** Penulis protobuf minimal (tanpa library), cukup untuk protokol Android TV Remote v2. */
class ProtoWriter {
    private val out = ByteArrayOutputStream()

    private fun varint(value: Long) {
        var v = value
        while (true) {
            if (v and 0x7FL.inv() == 0L) {
                out.write(v.toInt())
                return
            }
            out.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
    }

    private fun tag(field: Int, wireType: Int) = varint(((field shl 3) or wireType).toLong())

    fun int(field: Int, value: Long): ProtoWriter {
        tag(field, 0); varint(value); return this
    }

    fun int(field: Int, value: Int): ProtoWriter = int(field, value.toLong())

    fun bool(field: Int, value: Boolean): ProtoWriter = int(field, if (value) 1L else 0L)

    fun bytes(field: Int, value: ByteArray): ProtoWriter {
        tag(field, 2); varint(value.size.toLong()); out.write(value); return this
    }

    fun string(field: Int, value: String): ProtoWriter = bytes(field, value.toByteArray(Charsets.UTF_8))

    fun msg(field: Int, build: ProtoWriter.() -> Unit): ProtoWriter =
        bytes(field, ProtoWriter().apply(build).toByteArray())

    fun toByteArray(): ByteArray = out.toByteArray()

    companion object {
        fun encodeVarint(value: Int): ByteArray {
            val o = ByteArrayOutputStream()
            var v = value.toLong()
            while (true) {
                if (v and 0x7FL.inv() == 0L) { o.write(v.toInt()); break }
                o.write(((v and 0x7F) or 0x80).toInt()); v = v ushr 7
            }
            return o.toByteArray()
        }
    }
}

/** Pembaca protobuf minimal: mengelompokkan nilai per nomor field. */
class ProtoMsg(data: ByteArray) {
    private val fields = HashMap<Int, MutableList<Any>>()

    init {
        var pos = 0
        fun readVarint(): Long {
            var result = 0L
            var shift = 0
            while (true) {
                if (pos >= data.size) throw IllegalArgumentException("varint terpotong")
                val b = data[pos++].toInt() and 0xFF
                result = result or ((b and 0x7F).toLong() shl shift)
                if (b and 0x80 == 0) return result
                shift += 7
            }
        }
        while (pos < data.size) {
            val key = readVarint()
            val field = (key ushr 3).toInt()
            val value: Any = when ((key and 7).toInt()) {
                0 -> readVarint()
                1 -> { pos += 8; 0L }
                2 -> {
                    val len = readVarint().toInt()
                    val b = data.copyOfRange(pos, pos + len); pos += len; b
                }
                5 -> { pos += 4; 0L }
                else -> throw IllegalArgumentException("wire type tidak dikenal")
            }
            fields.getOrPut(field) { mutableListOf() }.add(value)
        }
    }

    fun has(field: Int) = fields.containsKey(field)
    fun long(field: Int, default: Long = 0): Long = (fields[field]?.lastOrNull() as? Long) ?: default
    fun int(field: Int, default: Int = 0): Int = long(field, default.toLong()).toInt()
    fun bytes(field: Int): ByteArray? = fields[field]?.lastOrNull() as? ByteArray
    fun msg(field: Int): ProtoMsg = ProtoMsg(bytes(field) ?: ByteArray(0))
    fun string(field: Int): String = bytes(field)?.toString(Charsets.UTF_8) ?: ""
    fun fieldNumbers(): Set<Int> = fields.keys
}

/** Pesan diawali panjang (varint), lalu isi protobuf. */
object Framing {
    fun write(out: OutputStream, payload: ByteArray) {
        synchronized(out) {
            out.write(ProtoWriter.encodeVarint(payload.size) + payload)
            out.flush()
        }
    }

    fun read(input: InputStream): ByteArray {
        var len = 0
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) throw EOFException("Koneksi ditutup TV")
            len = len or ((b and 0x7F) shl shift)
            if (b and 0x80 == 0) break
            shift += 7
        }
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(buf, off, len - off)
            if (n < 0) throw EOFException("Koneksi ditutup TV")
            off += n
        }
        return buf
    }
}
