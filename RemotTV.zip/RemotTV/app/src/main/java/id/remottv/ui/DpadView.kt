package id.remottv.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

/**
 * Cincin navigasi: atas/bawah/kiri/kanan + tombol OK di tengah.
 * Ditahan = diulang terus (berguna untuk menggulir daftar panjang).
 */
class DpadView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    enum class Part { UP, DOWN, LEFT, RIGHT, OK }

    var onPress: ((Part) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A3644.toInt() }
    private val pressedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A4A5D.toInt() }
    private val gapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1C2530.toInt(); strokeWidth = 3 * density; style = Paint.Style.STROKE
    }
    private val okPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF2C14E.toInt() }
    private val okPressedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD9A933.toInt() }
    private val okText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1C2530.toInt(); textAlign = Paint.Align.CENTER
        isFakeBoldText = true; textSize = 20 * density
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE6ECF2.toInt() }

    private var pressed: Part? = null
    private val handler = Handler(Looper.getMainLooper())
    private val repeater = object : Runnable {
        override fun run() {
            val p = pressed ?: return
            if (p != Part.OK) {
                onPress?.invoke(p)
                handler.postDelayed(this, 110)
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val size = min(w, (300 * density).toInt())
        setMeasuredDimension(w, size)
    }

    private val cx get() = width / 2f
    private val cy get() = height / 2f
    private val outerR get() = min(width, height) / 2f - 2 * density
    private val innerR get() = outerR * 0.40f

    override fun onDraw(canvas: Canvas) {
        val r = outerR
        canvas.drawCircle(cx, cy, r, ringPaint)
        val oval = RectF(cx - r, cy - r, cx + r, cy + r)
        val start = mapOf(Part.RIGHT to -45f, Part.DOWN to 45f, Part.LEFT to 135f, Part.UP to 225f)
        pressed?.let { p -> start[p]?.let { canvas.drawArc(oval, it, 90f, true, pressedPaint) } }

        // garis pemisah diagonal
        for (a in listOf(45.0, 135.0)) {
            val rad = Math.toRadians(a)
            val dx = (r * Math.cos(rad)).toFloat(); val dy = (r * Math.sin(rad)).toFloat()
            canvas.drawLine(cx - dx, cy - dy, cx + dx, cy + dy, gapPaint)
        }

        // panah
        val d = (r + innerR) / 2f
        drawChevron(canvas, cx, cy - d, 0f)
        drawChevron(canvas, cx + d, cy, 90f)
        drawChevron(canvas, cx, cy + d, 180f)
        drawChevron(canvas, cx - d, cy, 270f)

        canvas.drawCircle(cx, cy, innerR + 3 * density, gapPaint.apply { style = Paint.Style.FILL })
        gapPaint.style = Paint.Style.STROKE
        canvas.drawCircle(cx, cy, innerR, if (pressed == Part.OK) okPressedPaint else okPaint)
        canvas.drawText("OK", cx, cy - (okText.descent() + okText.ascent()) / 2, okText)
    }

    private fun drawChevron(c: Canvas, x: Float, y: Float, rot: Float) {
        val s = 9 * density
        val path = Path().apply {
            moveTo(-s, s * 0.45f); lineTo(0f, -s * 0.55f); lineTo(s, s * 0.45f)
            lineTo(s * 0.72f, s * 0.75f); lineTo(0f, -s * 0.05f); lineTo(-s * 0.72f, s * 0.75f); close()
        }
        c.save(); c.translate(x, y); c.rotate(rot); c.drawPath(path, arrowPaint); c.restore()
    }

    private fun partAt(x: Float, y: Float): Part? {
        val dx = x - cx; val dy = y - cy
        val dist = hypot(dx, dy)
        if (dist > outerR) return null
        if (dist < innerR) return Part.OK
        val deg = (Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360) % 360
        return when {
            deg >= 315 || deg < 45 -> Part.RIGHT
            deg < 135 -> Part.DOWN
            deg < 225 -> Part.LEFT
            else -> Part.UP
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = partAt(e.x, e.y) ?: return false
                pressed = p
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                onPress?.invoke(p)
                if (p != Part.OK) handler.postDelayed(repeater, 420)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(repeater)
                pressed = null
                invalidate()
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeater); super.onDetachedFromWindow()
    }
}
