package id.remottv.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Dua mode:
 * - PANAH: geser = langkah panah ke TV (scroll), ketuk = OK.
 * - MOUSE: geser = gerakkan kursor, ketuk = klik, geser dua jari = scroll,
 *          ketuk dua kali lalu tahan dan geser = seret.
 */
class TouchpadView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    enum class Dir { UP, DOWN, LEFT, RIGHT }
    enum class Mode { ARROWS, MOUSE }

    var mode = Mode.ARROWS
        set(value) { field = value; invalidate() }

    // mode panah
    var onStep: ((Dir) -> Unit)? = null
    var onTap: (() -> Unit)? = null

    // mode mouse
    var onMouseMove: ((Int, Int) -> Unit)? = null
    var onMouseWheel: ((Int) -> Unit)? = null
    var onMouseClick: (() -> Unit)? = null
    var onMouseButton: ((Boolean) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val step = 34 * density
    private val wheelStep = 22 * density
    private val tapSlop = 10 * density

    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8796A8.toInt(); textAlign = Paint.Align.CENTER; textSize = 14 * density
    }
    private val touchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55F2C14E }

    private var downX = 0f; private var downY = 0f
    private var lastX = 0f; private var lastY = 0f
    private var accX = 0f; private var accY = 0f
    private var fracX = 0f; private var fracY = 0f
    private var downTime = 0L
    private var lastTapUp = 0L
    private var moved = false
    private var touching = false
    private var twoFinger = false
    private var dragging = false

    override fun onDraw(canvas: Canvas) {
        if (touching) {
            canvas.drawCircle(lastX, lastY, 26 * density, touchPaint)
            return
        }
        val y = height / 2f
        val (a, b) = if (mode == Mode.ARROWS)
            "Geser untuk scroll" to "ketuk untuk OK"
        else
            "Geser untuk gerakkan kursor" to "ketuk = klik · dua jari = scroll"
        canvas.drawText(a, width / 2f, y - 4 * density, hint)
        canvas.drawText(b, width / 2f, y + 16 * density, hint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == Mode.MOUSE) return mouseTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                accX = 0f; accY = 0f; moved = false; touching = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                accX += e.x - lastX; accY += e.y - lastY
                lastX = e.x; lastY = e.y
                if (abs(e.x - downX) > tapSlop || abs(e.y - downY) > tapSlop) moved = true
                // ikuti sumbu yang dominan supaya scroll tidak "miring"
                if (abs(accY) >= abs(accX)) {
                    while (abs(accY) >= step) {
                        val up = accY < 0
                        fire(if (up) Dir.UP else Dir.DOWN)
                        accY += if (up) step else -step
                        accX = 0f
                    }
                } else {
                    while (abs(accX) >= step) {
                        val left = accX < 0
                        fire(if (left) Dir.LEFT else Dir.RIGHT)
                        accX += if (left) step else -step
                        accY = 0f
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                touching = false
                if (!moved) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onTap?.invoke()
                    performClick()
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { touching = false; invalidate() }
        }
        return true
    }

    private fun mouseTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                accY = 0f; fracX = 0f; fracY = 0f
                moved = false; touching = true; twoFinger = false
                downTime = e.eventTime
                // ketuk dua kali lalu tahan = tekan tombol kiri (untuk menyeret)
                if (e.eventTime - lastTapUp < 280) {
                    dragging = true
                    onMouseButton?.invoke(true)
                }
                invalidate()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                twoFinger = true
                moved = true
                lastY = avgY(e)
                accY = 0f
            }
            MotionEvent.ACTION_MOVE -> {
                if (twoFinger && e.pointerCount >= 2) {
                    val y = avgY(e)
                    accY += y - lastY
                    lastY = y
                    while (abs(accY) >= wheelStep) {
                        val up = accY < 0
                        // geser jari ke atas = konten ikut naik (seperti layar sentuh)
                        onMouseWheel?.invoke(if (up) -1 else 1)
                        accY += if (up) wheelStep else -wheelStep
                    }
                } else if (!twoFinger) {
                    val rawDx = e.x - lastX
                    val rawDy = e.y - lastY
                    lastX = e.x; lastY = e.y
                    if (abs(e.x - downX) > tapSlop || abs(e.y - downY) > tapSlop) moved = true
                    // percepatan: gerakan cepat membawa kursor lebih jauh
                    val speed = hypot(rawDx, rawDy) / density
                    val gain = (1.1f + speed * 0.12f).coerceAtMost(4f)
                    fracX += rawDx * gain; fracY += rawDy * gain
                    val ix = fracX.toInt(); val iy = fracY.toInt()
                    fracX -= ix; fracY -= iy
                    if (ix != 0 || iy != 0) onMouseMove?.invoke(ix, iy)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                touching = false
                if (dragging) {
                    dragging = false
                    onMouseButton?.invoke(false)
                    lastTapUp = 0
                } else if (!moved && !twoFinger && e.eventTime - downTime < 300) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onMouseClick?.invoke()
                    lastTapUp = e.eventTime
                    performClick()
                } else {
                    lastTapUp = 0
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                touching = false
                if (dragging) { dragging = false; onMouseButton?.invoke(false) }
                invalidate()
            }
        }
        return true
    }

    private fun avgY(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getY(i)
        return s / e.pointerCount
    }

    private fun fire(d: Dir) {
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onStep?.invoke(d)
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
