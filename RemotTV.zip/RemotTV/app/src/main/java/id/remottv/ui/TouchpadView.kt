package id.remottv.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Area geser untuk scroll. Setiap jarak geser tertentu dikirim sebagai satu langkah
 * panah ke TV, jadi geser panjang = scroll jauh. Ketuk = OK.
 */
class TouchpadView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    enum class Dir { UP, DOWN, LEFT, RIGHT }

    var onStep: ((Dir) -> Unit)? = null
    var onTap: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val step = 34 * density
    private val tapSlop = 10 * density

    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8796A8.toInt(); textAlign = Paint.Align.CENTER; textSize = 14 * density
    }
    private val touchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55F2C14E }

    private var downX = 0f; private var downY = 0f
    private var lastX = 0f; private var lastY = 0f
    private var accX = 0f; private var accY = 0f
    private var moved = false
    private var touching = false

    override fun onDraw(canvas: Canvas) {
        if (touching) {
            canvas.drawCircle(lastX, lastY, 26 * density, touchPaint)
        } else {
            val y = height / 2f
            canvas.drawText("Geser untuk scroll", width / 2f, y - 4 * density, hint)
            canvas.drawText("ketuk untuk OK", width / 2f, y + 16 * density, hint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                accX = 0f; accY = 0f; moved = false; touching = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                accX += e.x - lastX; accY += e.y - lastY
                lastX = e.x; lastY = e.y
                if (abs(e.x - downX) > tapSlop || abs(e.y - downY) > tapSlop) moved = true
                // ikuti sumbu yang dominan supaya scroll tidak "miring"
                if (abs(accY) >= abs(accX)) {
                    while (abs(accY) >= step) {
                        val up = accY < 0
                        fire(if (up) Dir.UP else Dir.DOWN)
                        accY += if (up) step else -step
                        accX = 0f
                    }
                } else {
                    while (abs(accX) >= step) {
                        val left = accX < 0
                        fire(if (left) Dir.LEFT else Dir.RIGHT)
                        accX += if (left) step else -step
                        accY = 0f
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                touching = false
                if (!moved) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onTap?.invoke()
                    performClick()
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { touching = false; invalidate() }
        }
        return true
    }

    private fun fire(d: Dir) {
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onStep?.invoke(d)
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
